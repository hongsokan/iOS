//
//  AlbumCollectionViewCell.swift
//  MyAlbum
//
//  Created by 안홍석 on 2020/11/05.
//

import UIKit

class AlbumCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var photoImageView: UIImageView!
}
