//
//  ListOfPhotosInAlbumCell.swift
//  07082018
//
//  Created by COMATOKI on 2018-07-09.
//  Copyright © 2018 COMATOKI. All rights reserved.
//

import UIKit

class ListOfPhotosInAlbumCell: UICollectionViewCell {
    @IBOutlet weak var photoImage: UIImageView!
    

}
